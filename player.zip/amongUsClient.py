from os import system
system("python get-pip.py")
system("pip install pygame")
system("pip install freegames")
from random import choice
from time import sleep
from turtle import *
import turtle
import pygame
from pygame import mixer
from sys import exit
import time
import socket
import pickle
from freegames import floor, square, vector


ClientSocket = socket.socket()
host = '192.168.10.125'
port = 1233
ClientSocket.settimeout(0.1)


print('Waiting for connection')
try:
    ClientSocket.connect((host, port))
except socket.error as e:
    print(str(e))

# pygame init
pygame.init()
mixer.init()
screen = pygame.display.set_mode((1280,720))
pygame.display.set_caption("PySquid")
clock = pygame.time.Clock()
font = pygame.font.Font('./fonts/ka1.ttf', 50)
font2 = pygame.font.Font('fonts/Amongus-3zjxX.ttf', 35)


stepSound = pygame.mixer.Sound('sound/Among-us-walking-sound-effect-160.mp3')
music =  pygame.mixer.Sound("sound/AMONG-US-Theme-Song-_Moondai-EDM-Remix_-_1-HOUR_-160.mp3")

# coordinations
x_player = 810
y_player = 510
playerID =  2
alive = True
imposter = False
playerLeft = 9

missionA = False
missionB = False
missionC = False

end = False
gameStart = False

permissionLeft = True
permissionRight = True
permissionUp = True
permissionDown = True

x_background = -2560
y_background = -1440

screenNumber = 1

# direction: false - left, true - right
direction = True
state = 1
idlePathRight = "animations/idleRight-" + str(playerID) + ".png"
idlePathLeft = "animations/idleLeft-" + str(playerID) + ".png"
walking01Right = "animations/walkingRight01-" + str(playerID) + ".png"
walking01Left = "animations/walkingLeft01-" + str(playerID) + ".png"
walking02Right = "animations/walkingRight02-" + str(playerID) + ".png"
walking02Left = "animations/walkingLeft02-" + str(playerID) + ".png"

# sufaces and rects
background = pygame.image.load('amongUsMap.png').convert()
player_surf = pygame.image.load(str(idlePathRight)).convert_alpha()
player_rect = player_surf.get_rect(center = (x_player,y_player))

# imposter options
kill_surf = pygame.image.load('assets/kButton.png').convert_alpha()
kill_rect = kill_surf.get_rect(center = (1150,650))
kill_rect_clicked = False
killed = 0
clickTime = 600
# 01
listKill_AparicioSurf = font2.render( "Aparicio 01", False, (64,64,64))
listKill_AparicioRect = listKill_AparicioSurf.get_rect(center = (60,470))
# 02
listKill_DaniSurf = font2.render( "Dani 02", False, (64,64,64))
listKill_DaniRect = listKill_DaniSurf.get_rect(center = (60,440))
# 03
listKill_LuisMSurf = font2.render( "LUIS M. 03", False, (64,64,64))
listKill_LuisMRect = listKill_LuisMSurf.get_rect(center = (60,410))
# 04
listKill_CarlosRSurf = font2.render( "CARLOS R. 04", False, (64,64,64))
listKill_CarlosRRect = listKill_CarlosRSurf.get_rect(center = (60,380))
# 05
listKill_CaboSurf = font2.render( "CABO 05", False, (64,64,64))
listKill_CaboRect = listKill_CaboSurf.get_rect(center = (60,350))
# 06
listKill_CarlosMSurf = font2.render( "CARLOS M. 06", False, (64,64,64))
listKill_CarlosMRect = listKill_CarlosMSurf.get_rect(center = (60,320))
# 07
listKill_JavierSurf = font2.render( "JAVIER 07", False, (64,64,64))
listKill_JavierRect = listKill_JavierSurf.get_rect(center = (60,290))
# 08
listKill_EloySurf = font2.render( "ELOY 08", False, (64,64,64))
listKill_EloyRect = listKill_EloySurf.get_rect(center = (60,260))
# 09
listKill_LuisSurf = font2.render( "LUIS 10", False, (64,64,64))
listKill_LuisRect = listKill_LuisSurf.get_rect(center = (60,230))

# texts

imposter_score_surf = font.render("Imposter: " + str(imposter), False, (64,64,64))
imposter_time_left = font.render((str(clickTime)), False, (64,64,64))

background_surf = font.render( "x: " + str(x_background) + " y: " + str(y_background), False, (0,0,255))
background_rect = background_surf.get_rect(center = (400,100))

# functions

def get_player(direction, state, x_player, y_player, playerID):
    direction = "Right" if direction else "Left"
    walking_state = "walking" if state != 1 else "idle"
    num = ""
    if state != 1:
        num = "01" if state % 4 == 0 else "02"
    return pygame.image.load("animations" + "/" + walking_state + direction + str(num) + "-" + str(playerID) + ".png").convert_alpha()

def right():
    global player_surf
    if state%4 == 0:  
        player_surf = pygame.image.load(walking01Right).convert_alpha()
    elif state%4 != 0:
        time.sleep(0.05)
        player_surf = pygame.image.load(walking02Right).convert_alpha()

def left():
    global player_surf
    if state%4 == 0:  
        player_surf = pygame.image.load(walking01Left).convert_alpha()
    elif state%4 != 0:
        time.sleep(0.05)
        player_surf = pygame.image.load(walking02Left).convert_alpha()

def background_adjust():
    global x_background, y_background, x_player, y_player, screenNumber

    if y_player > 680 and y_background == 0:
        y_background = -720
        y_player -= 720
    elif y_player > 680 and y_background == -720:
        y_background = -1440
        y_player -= 720
    elif y_player > 680 and y_background == -1440:
        y_background = -2160
        y_player -= 720
    elif y_player <= -150 and y_background == -2160:
        y_background = -1440
        y_player += 720    
    elif y_player <= -150 and y_background == -1440:
        y_background = -720
        y_player += 720
    elif y_player <= -150 and y_background == -720:
        y_background = 0
        y_player += 720
    
    if x_player > 1200 and x_background == 0:
            x_background = -1280
            x_player -= 1280
    elif x_player > 1200 and x_background == -1280:
            x_background = -2560
            x_player -= 1280
    elif x_player > 1200 and x_background == -2560:
            x_background = -3840
            x_player -= 1280
    elif x_player <= -175 and x_background == -3840:
        x_background = -2560
        x_player += 1280
    elif x_player <= -175 and x_background == -2560:
        x_background = -1280
        x_player += 1280
    elif x_player <= -175 and x_background == -1280:
        x_background = 0
        x_player += 1280

def missionACompleted():

    pattern = []
    guesses = []
    tiles = {
        vector(0, 0): ('red', 'dark red'),
        vector(0, -200): ('blue', 'dark blue'),
        vector(-200, 0): ('green', 'dark green'),
        vector(-200, -200): ('yellow', 'khaki'),
    }

    def grid():
        """Draw grid of tiles."""
        square(0, 0, 200, 'dark red')
        square(0, -200, 200, 'dark blue')
        square(-200, 0, 200, 'dark green')
        square(-200, -200, 200, 'khaki')
        update()


    def flash(tile):
        """Flash tile in grid."""
        glow, dark = tiles[tile]
        square(tile.x, tile.y, 200, glow)
        update()
        sleep(0.5)
        square(tile.x, tile.y, 200, dark)
        update()
        sleep(0.5)

    def grow():
        global missionA
        """Grow pattern and flash tiles."""
        tile = choice(list(tiles))
        pattern.append(tile)

        for tile in pattern:
            flash(tile)

        print('Pattern length:', len(pattern))
        if len(pattern) > 5:
            missionA = True
            turtle.title("MISSION COMPLETED!")
            turtle.bye()
            
        guesses.clear()

    def tap(x, y):
        """Respond to screen tap."""
        onscreenclick(None)
        x = floor(x, 200)
        y = floor(y, 200)
        tile = vector(x, y)
        index = len(guesses)

        if tile != pattern[index]:
            turtle.bye()   

        guesses.append(tile)
        flash(tile)

        if len(guesses) == len(pattern):
            grow()

        onscreenclick(tap)

    def start(x, y):
        """Start game."""
        grow()
        onscreenclick(tap)


    setup(420, 420, 370, 0)
    hideturtle()
    turtle.title("Mission A")
    tracer(False)
    grid()
    onscreenclick(start)
    done()

def missionBCompleted():

    pattern = []
    guesses = []
    tiles = {
        vector(0, 0): ('red', 'dark red'),
        vector(0, -200): ('blue', 'dark blue'),
        vector(-200, 0): ('green', 'dark green'),
        vector(-200, -200): ('yellow', 'khaki'),
    }

    def grid():
        """Draw grid of tiles."""
        square(0, 0, 200, 'dark red')
        square(0, -200, 200, 'dark blue')
        square(-200, 0, 200, 'dark green')
        square(-200, -200, 200, 'khaki')
        update()


    def flash(tile):
        """Flash tile in grid."""
        glow, dark = tiles[tile]
        square(tile.x, tile.y, 200, glow)
        update()
        sleep(0.5)
        square(tile.x, tile.y, 200, dark)
        update()
        sleep(0.5)

    def grow():
        global missionB
        """Grow pattern and flash tiles."""
        tile = choice(list(tiles))
        pattern.append(tile)

        for tile in pattern:
            flash(tile)

        print('Pattern length:', len(pattern))
        if len(pattern) > 5:
            missionB = True
            turtle.title("MISSION COMPLETED!")
            turtle.bye()
            
        guesses.clear()

    def tap(x, y):
        """Respond to screen tap."""
        onscreenclick(None)
        x = floor(x, 200)
        y = floor(y, 200)
        tile = vector(x, y)
        index = len(guesses)

        if tile != pattern[index]:
            turtle.bye()   

        guesses.append(tile)
        flash(tile)

        if len(guesses) == len(pattern):
            grow()

        onscreenclick(tap)

    def start(x, y):
        """Start game."""
        grow()
        onscreenclick(tap)


    setup(420, 420, 370, 0)
    hideturtle()
    turtle.title("Mission B")
    tracer(False)
    grid()
    onscreenclick(start)
    done()

def missionCCompleted():

    pattern = []
    guesses = []
    tiles = {
        vector(0, 0): ('red', 'dark red'),
        vector(0, -200): ('blue', 'dark blue'),
        vector(-200, 0): ('green', 'dark green'),
        vector(-200, -200): ('yellow', 'khaki'),
    }

    def grid():
        """Draw grid of tiles."""
        square(0, 0, 200, 'dark red')
        square(0, -200, 200, 'dark blue')
        square(-200, 0, 200, 'dark green')
        square(-200, -200, 200, 'khaki')
        update()


    def flash(tile):
        """Flash tile in grid."""
        glow, dark = tiles[tile]
        square(tile.x, tile.y, 200, glow)
        update()
        sleep(0.5)
        square(tile.x, tile.y, 200, dark)
        update()
        sleep(0.5)

    def grow():
        global missionC
        """Grow pattern and flash tiles."""
        tile = choice(list(tiles))
        pattern.append(tile)

        for tile in pattern:
            flash(tile)

        print('Pattern length:', len(pattern))
        if len(pattern) > 5:
            missionC = True
            turtle.title("MISSION COMPLETED!")
            turtle.bye()
            
        guesses.clear()

    def tap(x, y):
        """Respond to screen tap."""
        onscreenclick(None)
        x = floor(x, 200)
        y = floor(y, 200)
        tile = vector(x, y)
        index = len(guesses)

        if tile != pattern[index]:
            turtle.bye()   

        guesses.append(tile)
        flash(tile)

        if len(guesses) == len(pattern):
            grow()

        onscreenclick(tap)

    def start(x, y):
        """Start game."""
        grow()
        onscreenclick(tap)


    setup(420, 420, 370, 0)
    hideturtle()
    turtle.title("Mission C")
    tracer(False)
    grid()
    onscreenclick(start)
    done()

def screenCheck():
    global x_player, y_player, x_background, y_background, permissionLeft, permissionRight, permissionDown, permissionUp
    def upperWall():
        global y_player, permissionUp
        if y_player <= 40:
            permissionUp = False
            y_player += 10
    def westernWall():
        global x_player, permissionLeft
        if x_player <= -10:
            permissionLeft = False
            x_player += 10
    def easternWall():
        global x_player, permissionRight
        if x_player >= 1080:
            permissionRight = False
            x_player -= 10
    def bottomWall():
        global y_player, permissionDown
        if y_player >= 535:
            permissionDown = False
            y_player -= 10

    if x_background == 0 and y_background == 0: # screen 1
        upperWall()
        westernWall()
        if x_player > 870 and x_player < 999:
            if x_player > 870:
                permissionRight == False
                x_player -= 10
            elif x_player < 999:
                permissionLeft == False
                x_player += 30
    elif x_background == -1280 and y_background == 0: # screen 2
        upperWall()
        if x_player > 240 and x_player < 370:
            if x_player > 240:
                permissionRight == False
                x_player -= 10
            elif x_player < 370:
                permissionLeft == False
                x_player += 30
    elif x_background == -2560 and y_background == 0: # screen 3
        upperWall() 
        easternWall() 
    elif x_background == 0 and y_background == -720: # screen 4
        westernWall()
    elif x_background == -1280 and y_background == -720: # screen 5
        pass
    elif x_background == -2560 and y_background == -720: # screen 6
        easternWall()
    elif x_background == 0 and y_background == -1440: # screen 7
        westernWall()
        bottomWall()
    elif x_background == -1280 and y_background == -1440: # screen 8
        bottomWall()
    elif x_background == -2560 and y_background == -1440: # screen 9
        easternWall()
        bottomWall()

def clickedKillRect():
    # 01
    screen.blit(listKill_AparicioSurf,(listKill_AparicioRect))
    # 02
    screen.blit(listKill_DaniSurf,(listKill_DaniRect))
    # 03
    screen.blit(listKill_LuisMSurf,(listKill_LuisMRect))
    # 04
    screen.blit(listKill_CarlosRSurf,(listKill_CarlosRRect))
    # 05
    screen.blit(listKill_CaboSurf,(listKill_CaboRect))
    # 06
    screen.blit(listKill_CarlosMSurf,(listKill_CarlosMRect))
    # 07
    screen.blit(listKill_JavierSurf,(listKill_JavierRect))
    # 08
    screen.blit(listKill_EloySurf,(listKill_EloyRect))
    # 09
    screen.blit(listKill_LuisSurf,(listKill_LuisRect))

while True:
    music.play()
    # game controls
    for event in pygame.event.get():
        screenCheck()
        if pygame.key.get_pressed()[pygame.K_d] and permissionRight == True:
            state += 1
            direction = True
            x_player +=10
            right()
            background_adjust()
            stepSound.play()

        elif pygame.key.get_pressed()[pygame.K_w] and permissionUp == True:
            state += 1
            y_player -=10
            if direction == True:
                right()
            else:
                left()
            background_adjust()
            stepSound.play()

        elif pygame.key.get_pressed()[pygame.K_s] and permissionDown == True:
            state += 1
            y_player +=10
            if direction == True:
                right()
            else:
                left()
            background_adjust()
            stepSound.play()

        elif pygame.key.get_pressed()[pygame.K_a] and permissionLeft == True:
            state += 1
            direction = False
            x_player -=10
            if direction == True:
                right()
            else:
                left()
            background_adjust()
            stepSound.play()
            
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                try:
                    if ((x_player >= 520 and x_player <= 960) and (y_player >= 50 and y_player <= 300)) and (y_background == 0 and x_background == -2560):
                        missionACompleted()
                    elif ((x_player >= -30 and x_player <= 400) and (y_player >= -130 and y_player <= 90)) and (y_background == -1440 and x_background == -2560):
                        missionBCompleted()
                    elif ((x_player >= 350 and x_player <= 430) and (y_player >= 290 and y_player <= 500)) and (y_background == -1440 and x_background == -1280):
                        missionCCompleted()
                except Exception:
                    pass

        elif event.type == pygame.MOUSEBUTTONDOWN:
            try:
                if kill_rect.collidepoint(event.pos) and clickTime <= 0:
                    kill_rect_clicked = True
                    clickedKillRect()
                elif listKill_AparicioRect.collidepoint(event.pos) and clickTime  <= 0:
                        killed = 1
                        clickTime = 900
                        kill_rect_clicked = False
                elif listKill_DaniRect.collidepoint(event.pos):
                    killed = 2
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_LuisMRect.collidepoint(event.pos):
                    killed = 3
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_CarlosRRect.collidepoint(event.pos):
                    killed = 4
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_CaboRect.collidepoint(event.pos):
                    killed = 5
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_CarlosMRect.collidepoint(event.pos):
                    killed = 6
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_JavierRect.collidepoint(event.pos):
                    killed = 7
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_EloyRect.collidepoint(event.pos):
                    killed = 8
                    clickTime = 900
                    kill_rect_clicked = False
                elif listKill_CaboRect.collidepoint(event.pos):
                    killed = 10
                    clickTime = 900
                    kill_rect_clicked = False                                                           

            except Exception:
                pass

        else:
            state = 1
            if direction == True:
                player_surf = pygame.image.load(idlePathRight).convert_alpha()
            else:
                player_surf = pygame.image.load(idlePathLeft).convert_alpha()
            
        permissionLeft = True
        permissionRight = True
        permissionUp = True
        permissionDown = True

    
    # scores update
    score_surf = font.render( "x: " + str(x_player) + " y: " + str(y_player), False, (64,64,64))      
    background_surf = font.render( "x: " + str(x_background) + " y: " + str(y_background), False, (0,0,255))
    imposter_score_surf = font.render("Imposter: " + str(imposter), False, (64,64,64))
    imposter_time_left = font.render((str(clickTime)), False, (64,64,64))

    # drawing
    screen.blit(background,(x_background, y_background))
    #screen.blit(imposter_score_surf,(700,100))
    #screen.blit(imposter_time_left,(700,180))
    screen.blit(player_surf,(x_player,y_player))
    #screen.blit(score_surf, (score_rect))
    #screen.blit(background_surf, (background_rect))

    if kill_rect_clicked:
        clickedKillRect()

    # checking system
    if imposter == True:
        screen.blit(kill_surf, (kill_rect))

    #if player_rect.colliderect(player2_rect):
    #    playerID=10

    Gen_List = [direction, state, x_player,y_player, playerID, alive, imposter, x_background,y_background, killed, missionA, missionB, missionC, playerLeft, end]
    # sending to the server data
    ClientSocket.send(pickle.dumps(Gen_List))
    Response = None
    try:
        Response = ClientSocket.recv(1024)
    except socket.timeout as e:
        pass
    
    if Response:
        try:
            Response = pickle.loads(Response)
            if Response != Gen_List:
                #print(Response)
                for player_info_list in Response:
                    if len(player_info_list) < 2:
                        continue
                    # die
                    if playerID == player_info_list[9]:
                        player_surf = pygame.image.load("animations/grave.png").convert_alpha() # doesnt work yet
                        screen.blit(player_surf,(x_player,y_player))
                        quit()
                    # sync
                    if missionA != player_info_list[10]:
                        missionA = player_info_list[10]
                    elif missionB != player_info_list[11]:
                        missionB = player_info_list[11]
                    elif missionC != player_info_list[12]:
                        missionC = player_info_list[12]
                    elif playerLeft != player_info_list[13]:
                        playerLeft = player_info_list[13]
                    elif end != player_info_list[14]:
                        end = player_info_list[14]

                    if player_info_list[7] == x_background and player_info_list[8] == y_background:
                        # sequencial argument
                        player2_surf = get_player(*player_info_list[0:5]) # (player_info_list[0], player_info_list[1], player_info_list[2], player_info_list[3]))
                        player2_rect = player2_surf.get_rect(center = (player_info_list[2],player_info_list[3]))
                        background_rect = background_surf.get_rect(center = (400,100))
                        #screen.blit(player2_surf, (player2_rect))
                        screen.blit(player2_surf, (player_info_list[2],player_info_list[3]))
        except Exception as e:
            print(e,Response)
            Response = Response.decode()
            if Response == "I":
                imposter = True
                gameStart = True
            elif Response == "C":
                imposter = False
                gameStart = True
            elif Response == "DONE":
                end = True
    
    if playerLeft <= 2:
         end = True 
    if (missionA == True) and (missionB == True) and (missionC == True):
            end = True        
    if gameStart:
        clickTime -=1
    
    if end:
        if (missionA == True) and (missionB == True) and (missionC == True) and gameStart == True:
            score_surf = font.render("Crew Won", False, (64,64,64))
            screen.blit(score_surf,(700,100))
        elif playerLeft >= 2 and gameStart == True:
            score_surf = font.render("Impostors Won", False, (64,64,64))
            screen.blit(score_surf,(700,100))
        elif end == True:
            score_surf = font.render("Crew Won", False, (64,64,64))
            screen.blit(score_surf,(700,100))

    pygame.display.update()
    if state == 3:
        state == 1
    clock.tick(30)