import pygame
from sys import exit

pygame.init()
screen = pygame.display.set_mode((1280,720))
pygame.display.set_caption("Pygame")
clock = pygame.time.Clock()
background = pygame.image.load('menu/assets/background.jpg')
font = pygame.font.Font('menu/fonts/Amongus-3zjxX.ttf', 50)

#instructions
instruction_surf = font.render('Introduce your name please:', False, (255,255,255))
instruction_rect = instruction_surf.get_rect(center = (640,250))

#name
name = ""
name_surf = font.render( name , False, (255,255,255))
name_rect = name_surf.get_rect(center = (550,350))



while True:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.KEYDOWN:
            if event.key != pygame.K_KP_ENTER and len(name) <= 3:
                name = name + str(pygame.key.name(event.key))
            else:
               exec(open('amongUsClient.py').read())

    screen.blit(background,(0,0))
    
    #instructions_draw
    screen.blit(instruction_surf, (instruction_rect))

    #name_draw
    name_surf = font.render( name , False, (255,255,255))
    screen.blit(name_surf, (name_rect))
    

    pygame.display.update()
    clock.tick(30)
